from setuptools import setup

setup(
    name='Library_sink_package',
    version='1.0.0',
    description='Library of books',
    author='Sergiy Sinkevich',
    author_email='sinkevich2492@i.ua',
    packages=['Library_sink_package']
)